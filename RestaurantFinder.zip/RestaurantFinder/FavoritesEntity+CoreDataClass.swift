//
//  FavoritesEntity+CoreDataClass.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/11/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//
//

import Foundation
import CoreData


public class FavoritesEntity: NSManagedObject {

}
