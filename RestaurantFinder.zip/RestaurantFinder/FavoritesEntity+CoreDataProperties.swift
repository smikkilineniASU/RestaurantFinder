//
//  FavoritesEntity+CoreDataProperties.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/11/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//
//

import Foundation
import CoreData


extension FavoritesEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<FavoritesEntity> {
        return NSFetchRequest<FavoritesEntity>(entityName: "FavoritesEntity")
    }

    @NSManaged public var address: String?
    @NSManaged public var image: NSData?
    @NSManaged public var restaurantDescription: String?
    @NSManaged public var restaurantName: String?

}
