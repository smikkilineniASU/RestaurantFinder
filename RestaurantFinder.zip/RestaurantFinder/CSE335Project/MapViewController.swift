//
//  MapViewController.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/11/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {
    
    var lat:Double = 0.0
    var lon:Double = 0.0
    
    
    @IBOutlet weak var map: MKMapView!
    
    //Api key: c84902c72b262eda9d691cb2d3e880de

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let lat1:CLLocationDegrees = lat
        let lon1:CLLocationDegrees = lon

        let coordinates = CLLocationCoordinate2D(latitude:lat1, longitude:lon1)
        let span : MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)

        let region:MKCoordinateRegion = MKCoordinateRegionMakeWithDistance(coordinates, 1000, 1000)
        self.map.setRegion(region, animated: true)
        
        DispatchQueue.main.async(execute: {
            self.getJsonData()
        })
    }
    
    func getJsonData()
    {
        //API KEY: c84902c72b262eda9d691cb2d3e880de
        let api = "c84902c72b262eda9d691cb2d3e880de"
      
        let urlString = "https://developers.zomato.com/api/v2.1/geocode?&lat=\(lat)&lon=\(lon)";//Inputting the coordinates into url
        let url = NSURL(string: urlString)
        
        if url != nil
        {
            let request = NSMutableURLRequest(url: url! as URL)
            request.httpMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.addValue(api, forHTTPHeaderField: "user_key")
            
            let jsonQuery = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) -> Void in
                if error == nil
                {
                        do {
                            if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
                            {
                                if let restaurants = jsonResult["nearby_restaurants"] as? [NSDictionary]
                                {
                                    for x in restaurants
                                    {
                                        var searchResult = [String:AnyObject?]()
                                        let restaurant = x["restaurant"] as! NSDictionary
                               
                                        print(restaurant["name"] as? String)
                                       
                                        if let location = restaurant["location"] as? NSDictionary
                                        {
                                            print((location["latitude"] as? NSString)?.doubleValue)
                                            print((location["longitude"] as? NSString)?.doubleValue)
                                            print(location["address"] as? String)
                                            
                                            var a:Double = ((location["latitude"] as? NSString)?.doubleValue)!
                                            print(a)
                                           
                                            var b:Double = ((location["longitude"] as? NSString)?.doubleValue)!
                                            print(b)
                                            
                                            let coordinates = CLLocationCoordinate2D( latitude: a, longitude: b)


                                             let annotation = MKPointAnnotation()
                                             annotation.coordinate = coordinates
                                             annotation.title = restaurant["name"] as? String
                                            self.map.addAnnotation(annotation)
                                        }
                                    }
                                }
                            }
                        } catch {
                            print(error)
                        }
                }
            })
            jsonQuery.resume()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
