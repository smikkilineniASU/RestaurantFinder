//
//  RestaurantsToTryTableViewCell.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/22/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//

import UIKit

class RestaurantsToTryTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var restaurantName: UILabel!
    
    @IBOutlet weak var restaurantAddress: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
