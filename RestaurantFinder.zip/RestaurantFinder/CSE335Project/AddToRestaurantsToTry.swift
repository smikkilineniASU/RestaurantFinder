//
//  AddToRestaurantsToTry.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/22/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class AddToRestaurantsToTry
{
    var fetchResults = [RestaurantsToTryEntity]()
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    func getFetchCount()->(Int)
    {
        // Create a new fetch request using the FruitEntity
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "RestaurantsToTryEntity")
        var x   = 0
        // Execute the fetch request, and cast the results to an array of FruitEnity objects
        fetchResults = ((try? managedObjectContext.fetch(fetchRequest)) as? [RestaurantsToTryEntity])!
        
        x = fetchResults.count
        
        print(x)
        
        // return howmany entities in the coreData
        return x
    }
}
