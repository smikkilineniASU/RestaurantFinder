//
//  FavoritesTableViewController.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/11/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//

import UIKit
import CoreData

class FavoritesTableViewController: UITableViewController {
    
    var x:AddToFavorites = AddToFavorites()
    
    @IBOutlet var favoriteRestaurants: UITableView!
    
    // handler to the managege object context
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    
    func fetchRecord() -> Int
    {
        var a:Int
        a = x.getFetchCount()
        return a
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // number of rows based on the coredata storage
        return fetchRecord()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // add each row from coredata fetch results
        let cell = tableView.dequeueReusableCell(withIdentifier: "favoritesCell", for: indexPath) as! FavoritesTableViewCell
        cell.layer.borderWidth = 1.0
        cell.restaurantName.text = x.fetchResults[indexPath.row].restaurantName
        cell.restaurantAddress.text = x.fetchResults[indexPath.row].address
        return cell
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
     func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: IndexPath) -> UITableViewCellEditingStyle { return UITableViewCellEditingStyle.delete }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        
        if editingStyle == .delete
        {
            
            // delete the selected object from the managed
            // object context
            managedObjectContext.delete(x.fetchResults[indexPath.row])
            // remove it from the fetch results array
            x.fetchResults.remove(at:indexPath.row)
            
            do {
                // save the updated managed object context
                try managedObjectContext.save()
            } catch {
                
            }
            // reload the table after deleting a row
            favoriteRestaurants.reloadData()
        }
        
    }
    
    
    @IBAction func addFavoriteRestaurant(_ sender: UIBarButtonItem)
    {
        // create a new entity object
        let ent = NSEntityDescription.entity(forEntityName: "FavoritesEntity", in: self.managedObjectContext)
        
        let alert = UIAlertController(title: "Add Restaurant", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Enter Name of the Restaurant Here"
        })
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Enter Address of the Restaurant Here"
        })

        //Prompt User to enter Name AND Address
        self.present(alert, animated: true)
       
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            
           let newItem = FavoritesEntity(entity: ent!, insertInto: self.managedObjectContext)
            // Do this first, then use method 1 or method 2
            if let name = alert.textFields?.first?.text {
                print("Restaurant name: \(name)")
              
                newItem.restaurantName = name
               
                //Method 2
                self.favoriteRestaurants.reloadData()
            }
            // Do this first, then use method 1 or method 2
            if let address = alert.textFields![1].text {
                print("Restaurant Address: \(address)")
               
                newItem.address = address
                
                //Method 2
                self.favoriteRestaurants.reloadData()
            }
        }))
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
