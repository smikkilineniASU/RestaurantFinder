//
//  FavoritesDetailViewController.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/22/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//

import UIKit
import CoreData


class FavoritesDetailViewController: UIViewController {
    
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var restaurantDescription: UILabel!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func addInfo(_ sender: Any)
    {
        let ent = NSEntityDescription.entity(forEntityName: "FavoritesEntity", in: self.managedObjectContext)
        
        let alert = UIAlertController(title: "Add Description about Restaurant", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Enter Description of the Restaurant Here"
        })
        //Prompt User to enter Name AND Address
        self.present(alert, animated: true)
        
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            let newItem = FavoritesEntity(entity: ent!, insertInto: self.managedObjectContext)
            // Do this first, then use method 1 or method 2
            if let name = alert.textFields?.first?.text {
                print("Restaurant name: \(name)")
                newItem.restaurantDescription = name
                self.restaurantDescription.text = name
            }
          
        }))

    }
    
}
