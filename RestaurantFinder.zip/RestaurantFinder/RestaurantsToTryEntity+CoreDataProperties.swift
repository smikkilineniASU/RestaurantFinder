//
//  RestaurantsToTryEntity+CoreDataProperties.swift
//  CSE335Project
//
//  Created by Snehit Mikkilineni on 4/11/18.
//  Copyright © 2018 Snehit Mikkilineni. All rights reserved.
//
//

import Foundation
import CoreData


extension RestaurantsToTryEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<RestaurantsToTryEntity> {
        return NSFetchRequest<RestaurantsToTryEntity>(entityName: "RestaurantsToTryEntity")
    }

    @NSManaged public var address: String?
    @NSManaged public var restaurantName: String?

}
